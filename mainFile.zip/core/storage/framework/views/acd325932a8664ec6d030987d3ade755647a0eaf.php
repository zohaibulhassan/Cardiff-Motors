

<div class="row align-items-center mb-30 justify-content-between">
    <div class="col-lg-5 col-sm-3 col-md-4">
        <h6 class="page-title"><?php echo e(__($pageTitle)); ?></h6>
    </div>
    <div class="col-lg-7 col-sm-9 col-md-8  mt-sm-0 mt-3 ">
        <div class="d-flex flex-wrap justify-content-end text-sm-right right-part">
            <?php echo $__env->yieldPushContent('breadcrumb-plugins'); ?>
        </div>
    </div>
</div>
<?php /**PATH F:\xampp\htdocs\laravel\dealshop\core\resources\views/admin/partials/breadcrumb.blade.php ENDPATH**/ ?>